package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;

public class Barn {
    Texture barnImg; //image of the barn
    Texture bWindow; // window image when barn is clicked
    boolean barnClicked; // state of the barn
    int posX;
    int posY;
    int level; //level of the barn
    int[] upgradeCosts = new int[]{100, 200, 300, 400, 500, 600, 700}; //cost for upgrades

    public Barn(){
        level = 0;
        barnClicked = false;
    }
    public Barn(int x, int y) {
        barnImg = new Texture("barn/barn.png");
        bWindow = new Texture("barn/bWindow.png");
        barnClicked = false;
        posX = x;
        posY = y;
        level = 0;
    }

    public boolean isCollided(int pX,int pY){
        return true;
    }

    public int upgrade(int money) {
        if (money >= upgradeCosts[level]) {
            return upgradeCosts[level++];
        }
        return -upgradeCosts[level];
    }

    public void setWindow(String img) {
        bWindow = new Texture(img);
    }

    public int getLevel() {
        return level;
    }
}
