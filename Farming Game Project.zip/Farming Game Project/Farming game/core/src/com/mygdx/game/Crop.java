package com.mygdx.game;

import java.util.Timer;
import java.util.TimerTask;

import com.badlogic.gdx.graphics.Texture;


public class Crop {

	double price;
	int quantity;
    String name;  // name of Crop
    Texture cropImg; // texture of the crop field
    Texture cropGrowthImg;
    Texture cWindow;
    int growthTime;  // time it takes to mature in seconds
    int growthStage;  // stage of growth (stage 4 = maturity, 1 is earliest)
    int timePlanted; // amount of time plant has been planted
//    boolean stasis;  // true if crop is stored in inventory, false everywhere else
//    int hydration;  // cap of hydration for this crop
    int cropID;  // id of crop
//	static int cropIDCount = 0;  // count of crop IDS
    boolean isFull;
    boolean readyToHarvest;
    boolean isClicked;
    boolean isPlanted;
	int x;
	int y;  // coordinates that are going to be stored in game
	boolean isSelected;
	boolean unlocked;
//	Timer T = new Timer();
//	TimerTask cropGrowth = new TimerTask() {
//	
//		public void run() {
//			readyToHarvest = true;
//			System.out.println("The crops are ready to harvest");
////			T.purge();
//		}
//
//	
//		
//	};
	


    //
    // Constructor for Crop
    //
	public Crop(int id,int posX, int posY) {
		x = posX;
		y = posY;
		this.cropID=id;
		isFull = false;
		readyToHarvest = false;
		isClicked = false;
		isPlanted = false;
		isSelected = false;
		unlocked = false;
		
	}

	public Crop(int id,int posX, int posY,double price) {
		x = posX;
		y = posY;
		this.cropID=id;
		this.price=price;
		isFull = false;
		readyToHarvest = false;
		isClicked = false;
	}
	public boolean isUnlocked() {
		return unlocked;
	}
	public void setUnlocked(boolean unlock) {
		unlocked = unlock;
	}

	public void setCropImg(Texture cropImg) {
		this.cropImg = cropImg;
	}

	public boolean isReadyToHarvest() {
		return readyToHarvest;
	}

	public void setcWindow(Texture cWindow) {
		this.cWindow = cWindow;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setPlant(boolean planted) {
		isPlanted = planted;
	}
	public boolean getPlanted() {
		return isPlanted;
	}
	public void setFull(boolean full) {
		isFull = full;
	}
	public boolean getFull() {
		return isFull;
	}
	public void setIsSelect(boolean select) {
		isSelected = select;
	}
	public boolean getIsSelect() {
		return isSelected;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public int getCropID() {
		return cropID;
	}
	

	public double getPrice() {
		return price;
	}
	public void runCropTime(Timer T) {
		T.schedule(new TimerTask() {
			public void run() {
				readyToHarvest = true;
				System.out.println("The crops are ready to harvest");
			}	
		}, 5000);
	}
	//	public Crop(String name, int growthTime, int hydration, int x, int y){
//        this.name = name;
//        this.growthTime = growthTime;
//        this.hydration = hydration;
//        stasis = true;
//        this.x = x;
//        this.y = y;
//        cropID = cropIDCount;
//        cropIDCount++;
//	}
//	
//
//    //
//    // called when crop is put into farmland
//    //
//    public void plant() {
//        stasis = false;
//        timePlanted = 0;
//        growthStage = 1;
//    }
//    //
//    // getter for timePlanted
//    //
//	public int getTimePlanted(){
//		return this.timePlanted;
//	}
//
//    //
//    // ranks up growthStage if time is met
//    //
//    public void grow() {
//        if (timePlanted >= growthTime/growthStage) {
//            growthStage++;
//        }
//    }
//
//    //
//    // getter for growthStage
//    //
//	public int getGrowthStage(){
//		return this.growthStage;
//	}
//	
//    //
//    // getter for growthTime
//    //
//	public int getGrowthTime(){
//		return this.growthTime;
//	}
//
//    //
//    // getter for name
//    //
//	public String getName(){
//		return this.name;
//	}
//    //
//    // how to tell if crop == crop
//    //
    public boolean equals(Crop other) {
        if(this.cropID == other.cropID) {
            return true;
        }
        return false;
    }
//    
//    public int getX() {
//    	return this.x;
//    }
//    public int getY() {
//    	return this.y;
//    }
}
