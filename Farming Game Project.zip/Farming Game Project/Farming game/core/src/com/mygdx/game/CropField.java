package com.mygdx.game;

import java.util.Hashtable;
import java.util.Timer;
import java.util.TimerTask;

import com.badlogic.gdx.graphics.Texture;


public class CropField {
    Crop[] crops = new Crop[10];
    int level = 0;
    int capacity = 0;
    boolean itemSelect = false;
    int[] prices = {50, 75, 100, 125, 150, 175, 200, 225, 250, 275};
    Hashtable<String, Integer> seedSelect = new Hashtable<String, Integer>();


    public CropField() {
        seedSelect.put("carrot seed", 0);
        seedSelect.put("corn seed", 1);
        seedSelect.put("potato seed", 2);
        seedSelect.put("wheat seed", 3);
        seedSelect.put("tomato seed", 4);
        seedSelect.put("sunflower seed", 5);
        seedSelect.put("watermelon seed", 6);
        int posx = 350;
        int posy = 350;
        for (int i = 0; i < 10; i++) {
            if (i == 5) {
                posx = 350;
                posy = 250;
            }
            crops[i] = new Crop(i, posx, posy);
            crops[i].setCropImg(new Texture("dirtPatch.png"));
            crops[i].setcWindow(new Texture("crop/cWindow.png"));
            posx = posx - 80;
        }
        crops[0].setUnlocked(true);
    }

    public int upgrade(int money) {
        if (level < 9 && money >= prices[level]) {
            money -= prices[level];
            level++;
            crops[level].setUnlocked(true);
        }
        return money;
    }

    public int getX(int i) {
        return crops[i].x;
    }

    public int getY(int i) {
        return crops[i].y;
    }

    public Texture getImg(int i) {
        return crops[i].cWindow;
    }

    public void setIMG(int i, String img) {
        crops[i].cWindow = new Texture(img);
    }

    public void setCropIMG(int i, String img) {
        crops[i].cropGrowthImg = new Texture(img);
    }

    public Texture getCropIMG(int i) {
        return crops[i].cropGrowthImg;
    }

    public void removeCropIMG(int i) {
        crops[i].cropGrowthImg.dispose();
    }

    public void setClicked(int i, boolean clicked) {
        crops[i].isClicked = clicked;
    }

    public boolean getClicked(int i) {
        return crops[i].isClicked;
    }

    public void removeImg(int i) {
        crops[i].cWindow.dispose();
    }

    public void growCrops(int i) {
        Timer T = new Timer();
        crops[i].runCropTime(T);
        crops[i].isPlanted = true;
    }

    public boolean getHarvest(int i) {
        return crops[i].readyToHarvest;
    }

    public void setHarvest(int i, boolean isHarvest) {
        crops[i].readyToHarvest = isHarvest;
    }

    public void setPlant(int i, boolean planted) {
        crops[i].isPlanted = planted;
    }

    public boolean getPlant(int i) {
        return crops[i].isPlanted;
    }

    public boolean getSelect(int i) {
        return crops[i].isSelected;
    }

    public void setSelect(int i, boolean select) {
        crops[i].isSelected = select;
    }

    public int getCropNum(int i) {
        String name = crops[i].name;
        crops[i].name = "";
        return seedSelect.get(name);
    }

    public int getCropNum2(int i) {

        return seedSelect.get(crops[i].name);
    }

    public void setCropName(int i, String name) {
        crops[i].name = name;
    }

    public String getCropName(int i) {
        String name = crops[i].name;
        crops[i].name = "";
        return name;
    }
}
