package com.mygdx.game;

//
// Farmland class, basically a visible inventory. Very similar to inventory class
//
public class Farmland {
    public Crop planted;  //
    public boolean full;
    public int x;
    public int y;
    public int plotNumber;
    
    //
    // Constructor for Farmland
    //
	public Farmland(int x, int y, int plotNumber){
		this.x = x;
		this.y = y;
		full = false;
		this.plotNumber = plotNumber;
	}
	
	public int harvest () {
		planted = null;
		return 5;
	}
	
	public void plant(Crop c) {
		this.planted = c;
		full = true;
	}
	
	
}