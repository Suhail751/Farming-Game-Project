package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.assets.loaders.AssetLoader;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;

public class GameScreen implements Screen {
    FarmingSim game;
    Shop shop;
    Texture img;
    //	Texture barn;
    Barn barn;
    Texture test;
    Inventory inventory;
    //	Farmland[] farmland;
    CropField crops;
    int money;
    String moneyDisplay;
    int numFarms;
    BitmapFont bmf;
    //	int farmX = 50;
//	int farmY = 50;
    Texture dirt;
    Texture coin;
    SpriteBatch coins;
    Stage stage;
    SpriteBatch batch;
    Texture player;
    Texture inventoryImg;
    float Speed = 100.0f;
    float playerx = 0;
    float playery = 0;
    boolean menuOccupide = false;

    //	boolean barnClicked = false;
//	Texture bWindow;
    //
    // constructor for game screen
    //
    public boolean objectRange(double left, double right, double top, double bottom) {
        if (Gdx.input.getX() > left && Gdx.input.getX() < right && Gdx.input.getY() < top && Gdx.input.getY() > bottom) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isInBarn(float playerx, float playery) {
        return playerx > barn.posX && playerx < barn.posX + 230 && playery + 50 > barn.posY && playery < barn.posY + 250;
    }

    public GameScreen(FarmingSim game) {
        this.game = game;
//		dirt = new Texture("dirtPatch.png");
        img = new Texture("bg.png");
        barn = new Barn(FarmingSim.WIDTH / 3, FarmingSim.HEIGHT / 3);
        shop = new Shop(660, 50);
//		bWindow = new Texture("bWindow.png");
//		test = new Texture("test2.png");
        this.inventory = new Inventory();
//		this.farmland = new Farmland[4];
        crops = new CropField();
        numFarms = 0;
        this.money = 2000;//50$
        this.bmf = new BitmapFont();
//		this.farmland[0] = new Farmland(farmX, farmY, numFarms);
        numFarms++;


    }

    @Override
    public void show() {

        player = new Texture("player.png");
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);
        batch = new SpriteBatch();
        coin = new Texture("coin.png");
        coins = new SpriteBatch();

    }

    /* (non-Javadoc)
     * @see com.badlogic.gdx.Screen#render(float)
     */
    @Override
    public void render(float delta) {
        // TODO Auto-generated method stub
        Gdx.gl.glClearColor(0.15f, 0.15f, 0.3f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();
        game.batch.draw(img, 0, 0);
        batch.begin();
        stage.draw();
        batch.draw(player, playerx, playery);

//		System.out.println(Gdx.input.getX());
//		System.out.println(Gdx.input.getY());
        bmf.setColor(Color.RED);  // red text
        this.moneyDisplay = ": $" + money;
        bmf.draw(game.batch, moneyDisplay, 50, FarmingSim.HEIGHT - 100);
        bmf.draw(game.batch, "tip: click on dirt patch in left corner to plant free carrot seed x1", 700, FarmingSim.HEIGHT - 100);
        game.batch.draw(barn.barnImg, barn.posX, barn.posY);
        if (objectRange((barn.posX + 75), (barn.posX + 225), (FarmingSim.HEIGHT * .67 - 45), (FarmingSim.HEIGHT * .67 - 345))) {

            if (Gdx.input.isTouched() && !barn.barnClicked) {
                System.out.println("I'm in");
                barn.barnClicked = true;
            }

        }

//		Texture shop = new Texture("shop/shopButton.png");
        inventoryImg = new Texture("inventory.jpg");
        // The Inventory
        game.batch.draw(inventoryImg, 780, 0);

        //display inventory quantities
        for (int i = 0; i < this.inventory.items.length; i++) {
            for (int j = 0; j < this.inventory.items[i].length; j++) {
                Crop c = this.inventory.items[i][j];
                bmf.draw(game.batch, c.quantity + "", c.x, FarmingSim.HEIGHT - c.y - 12);
            }
        }

        if (barn.barnClicked) {
//			System.out.println("top: " + (FarmingSim.HEIGHT*.67 + 175));
//			System.out.println("bottom: " +(FarmingSim.HEIGHT*.67 + 100));
            if (objectRange(FarmingSim.WIDTH / 3 + 200, FarmingSim.WIDTH / 3 + 275, 257, 224)) {
                barn.setWindow("barn/bWindowUpgrade.png");
                if (Gdx.input.isTouched()) {
                    int amount = barn.upgrade(money);
                    if (amount > 0) {
                        money -= amount;
                        barn.barnClicked = false;
                        System.out.println("Upgraded to level " + (barn.level + 1));
                    } else {
                        System.out.println("Not enough money to upgrade!");
                        System.out.println("Required: " + Math.abs(amount));
                    }
                }

            } else if (objectRange(690, 700, 215, 205)) {
                barn.setWindow("barn/bExit.png");
                if (Gdx.input.isTouched()) {
                    barn.bWindow.dispose();
                    barn.barnClicked = false;
                }
            } else {
                barn.setWindow("barn/bWindow.png");

            }
            game.batch.draw(barn.bWindow, barn.posX + 200, barn.posY + 200);
        }
        // This is the crops location
        for (int i = 0; i < 10; i++) {
//			bmf.draw(game.batch,"testdhfoigndojndo",20,20);
        	if(crops.crops[i].isUnlocked()) {
        		game.batch.draw(crops.crops[i].cropImg, crops.crops[i].x, crops.crops[i].y);

        	}
            
            if (i < 5 && crops.crops[i].isUnlocked()) {
                if (objectRange(crops.getX(i), crops.getX(i) + 75, 350, 290)) {
                    if (Gdx.input.isTouched() && crops.getClicked(i) == false && menuOccupide == false) {
                        crops.setClicked(i, true);
                        crops.setSelect(i, true);
                        menuOccupide = true;
                    }
                }

            } else if (i >= 5 && crops.crops[i].isUnlocked()) {
                if (objectRange(crops.getX(i), crops.getX(i) + 75, 440, 370)) {
                    if (Gdx.input.isTouched() && crops.getClicked(i) == false && menuOccupide == false) {
                        crops.setClicked(i, true);
                        crops.setSelect(i, true);
                        menuOccupide = true;
                    }
                }
            }
            if (crops.getClicked(i) && crops.getSelect(i)) {
                game.batch.draw(crops.getImg(i), crops.getX(i) + 40, crops.getY(i) + 40);
                int x = crops.getX(i) + 40;
                int y = FarmingSim.HEIGHT - (crops.getY(i) + 40);
//				System.out.println("x: " + x + " y: " + y + " range up to down: " + (y - 75) + " " + (y - 50));
                if (objectRange(x, x + 69, y - 50, y - 75)) { // Window crop plant
                    crops.setIMG(i, "crop/cWindowPlant.png");
                    game.batch.draw(crops.getImg(i), crops.getX(i) + 40, crops.getY(i) + 40);
                    if (Gdx.input.isTouched() && !crops.getPlant(i) && crops.itemSelect && inventory.checkExist()) {
                        crops.setPlant(i, true);
                        crops.setCropIMG(i, "carrot_stage2.png");
                        game.batch.draw(crops.getCropIMG(i), crops.getX(i), crops.getY(i));
                        crops.growCrops(i);
                        crops.setClicked(i, false);
                        crops.setSelect(i, false);
                        menuOccupide = false;
                        crops.removeImg(i);
                        crops.itemSelect = false;
                        crops.setCropName(i, inventory.getSelect());

                    }
                } else if (objectRange(x, x + 75, y - 25, y - 50)) { //Window Crop Upgrade
                    crops.setIMG(i, "crop/cWindowUpgrade.png");
                    game.batch.draw(crops.getImg(i), crops.getX(i) + 40, crops.getY(i) + 40);
                    if(Gdx.input.isTouched()) {
                    	money = crops.upgrade(money);
                    	crops.removeImg(i);
                    	crops.setClicked(i, false);
                        crops.setSelect(i, false);
                        menuOccupide = false;
                    }
                } else if (objectRange(x, x + 75, y, y - 25)) { // Window Crop Harvest
                    crops.setIMG(i, "crop/cWindowHarvest.png");
                    game.batch.draw(crops.getImg(i), crops.getX(i) + 40, crops.getY(i) + 40);
                    if (Gdx.input.isTouched() && crops.getHarvest(i)) {
                        crops.setHarvest(i, false);
                        crops.setPlant(i, false);
                        crops.setCropIMG(i, "dirtPatch.png");
                        game.batch.draw(crops.getCropIMG(i), crops.getX(i), crops.getY(i));
                        crops.removeImg(i);
                        crops.removeCropIMG(i);
                        inventory.collectCrop(1, crops.getCropNum(i), 4);
//                        inventory.items[2][1].setQuantity(4);
//                        System.out.println("4 carrots have been harvested");
                        crops.setClicked(i, false);
                        crops.setSelect(i, false);
                        menuOccupide = false;
                    }
                } else if (objectRange(x + 65, x + 75, y - 65, y - 75)) {
                    crops.setIMG(i, "crop/cWindowExit.png");
                    game.batch.draw(crops.getImg(i), crops.getX(i) + 40, crops.getY(i) + 40);
                    if (Gdx.input.isTouched()) {
                        crops.removeImg(i);
                        crops.setClicked(i, false);
                        crops.setSelect(i, false);
                        menuOccupide = false;
                    }
                } else {
                    crops.setIMG(i, "crop/cWindow.png");
                    game.batch.draw(crops.getImg(i), crops.getX(i) + 40, crops.getY(i) + 40);

                }

            }
            if (crops.getHarvest(i)) {
                crops.setIMG(i, "carrot_stage4.png");
                game.batch.draw(crops.getImg(i), crops.getX(i), crops.getY(i));
            }
        } // end of crop loop

        // Start of item select from inventory
        for (int i = 0; i < 7; i++) {
            int x = inventory.getItemX(i);
            int y = FarmingSim.HEIGHT - inventory.getItemY(i);
            if (objectRange(x, x + 69, y, y - 50)) {
                if (Gdx.input.isTouched()) {
//        			inventory.selectBox.dispose();
//        			game.batch.draw(inventory.selectBox, x, inventory.getItemY(i));
                    inventory.setSelect(i);
                    crops.itemSelect = true;
                }
//        		System.out.println("I'm in " + inventory.getItemName(i));
            }
            if (inventory.matchSelect(i)) {
                Texture selectBox = new Texture("selectBox.png");
                game.batch.draw(selectBox, x, inventory.getItemY(i));
            }
        } // end of item loop

        if (Gdx.input.isKeyPressed(Input.Keys.W) && playery < 360) {
            System.out.println("W");
            if (isInBarn(playerx, playery)) {
                playery -= 10;
            } else {
                playery += Gdx.graphics.getDeltaTime() * Speed;
            }
        }
        if (Gdx.input.isKeyPressed(Input.Keys.S) && playery > 0) {
            System.out.println("S");
            if (isInBarn(playerx, playery)) {
                playery += 10;
            } else {
                playery -= Gdx.graphics.getDeltaTime() * Speed;
            }
        }
        if (Gdx.input.isKeyPressed(Input.Keys.A) && playerx > 0) {
            System.out.println("A");

            if (isInBarn(playerx, playery)) {
                playerx += 10;
            } else {
                playerx -= Gdx.graphics.getDeltaTime() * Speed;
            }
        }
        if (Gdx.input.isKeyPressed(Input.Keys.D) && playerx < 1200) {

            System.out.println("D");

            if (isInBarn(playerx, playery)) {
                playerx -= 10;
            } else {
                playerx += Gdx.graphics.getDeltaTime() * Speed;
            }
        }
        // The shop
        game.batch.draw(shop.getButtonImg(), shop.getButtonX(), shop.getButtonY());
        int bY = FarmingSim.HEIGHT - shop.getButtonY();
        if (objectRange(shop.getButtonX(), shop.getButtonX() + 75, bY, bY - 50)) {
            if (Gdx.input.isTouched() && !shop.getClicked()) {
//				game.batch.draw(shop.getMenuImg(), shop.getMenuX(), shop.getMenuY());
                shop.setClicked(true);
                menuOccupide = true;
            }
        }


        if (shop.getClicked()) {
            if (shop.isSelling) {
                //sell image
                game.batch.draw(shop.getMenuImg(), shop.getMenuX(), shop.getMenuY());
                if (objectRange(1100, 1140, 40, 10)) {
                    shop.setMenuImg("shop/shopSellExit.png");
                    game.batch.draw(shop.getMenuImg(), shop.getMenuX(), shop.getMenuY());
                    if (Gdx.input.isTouched()) {
                        shop.removeImg();
                        shop.setClicked(false);
                        menuOccupide = false;
                    }
                } else {
                    shop.setMenuImg("shop/shopSell.png");
                    game.batch.draw(shop.getMenuImg(), shop.getMenuX(), shop.getMenuY());
                }

                //Sell functionality
                if (Gdx.input.isTouched()) {
                    if (objectRange(150, 350, 190, 130)) {
                        shop.setMenuImg("shop/shopBuy.png");
                        shop.setSelling(false);
                    } else {
                        for (Crop c : shop.sellItems) {
                            boolean sold = false;
                            boolean sellOne = false;
                            int quantity = 0;

                            //check if clicked on 'Sell'
                            if (objectRange(c.x - 40, c.x, c.y + 10, c.y - 10)) {
                                if ((quantity = this.inventory.sellCrop(c, false)) > 0) {
                                    sold = true;
                                    sellOne = true;
                                }
                            }
                            // else if clicked on 'Sell All'
                            else if (objectRange(c.x, c.x + 40, c.y + 10, c.y - 10)) {
                                if ((quantity = this.inventory.sellCrop(c, true)) > 0) {
                                    sold = true;
                                }
                            }

                            // sold if enough quantity, remove Inventory image
                            if (sold) {
                                shop.removeImg();
                                shop.setClicked(false);
                                menuOccupide = false;
                                if (sellOne) {
                                    money += c.price;
                                } else {
                                    money += c.price * quantity;
                                }

                            }
                        }
                    }
                }
            } else {
                //Buy image

                game.batch.draw(shop.getMenuImg(), shop.getMenuX(), shop.getMenuY());
                if (objectRange(1100, 1140, 40, 10)) {
                    shop.setMenuImg("shop/shopBuyExit.png");
                    game.batch.draw(shop.getMenuImg(), shop.getMenuX(), shop.getMenuY());
                    if (Gdx.input.isTouched()) {
                        shop.removeImg();
                        shop.setClicked(false);
                        menuOccupide = false;
                    }
                } else {
                    shop.setMenuImg("shop/shopBuy.png");
                    game.batch.draw(shop.getMenuImg(), shop.getMenuX(), shop.getMenuY());
                }

                //Buy functionality
                if (Gdx.input.isTouched()) {
                    if (objectRange(400, 600, 190, 130)) {
                        shop.setMenuImg("shop/shopSell.png");
                        shop.setSelling(true);
                    } else {
                        for (int i=0;i<=barn.level;i++) {
                            Crop c=this.shop.getItems().get(i);
                            if (objectRange(c.x - 40, c.x + 40, c.y + 10, c.y - 10)) {
                                if (money >= c.price) {
                                    shop.removeImg();
                                    shop.setClicked(false);
                                    menuOccupide = false;
                                    money -= c.price;
                                    this.inventory.addSeed(c);
                                }
                            }
                        }
                    }
                }
            }


        }

//		game.batch.draw(test, 100, 30);

//		game.batch.draw(test, 780, 0);
//		game.batch.draw(dirt, farmX, farmY);
//		if(this.farmland[0].full == false && Gdx.input.getX() > farmX && Gdx.input.getX() < farmX + 75 && Gdx.input.getY() < FarmingSim.HEIGHT - farmY && Gdx.input.getY() > FarmingSim.HEIGHT - farmY - 75) {
//			Texture dh = new Texture("dirt_highlight.png");
//			game.batch.draw(dh, farmX, farmY);
//			if (Gdx.input.isTouched()) {
//				this.farmland[0].plant(new Crop("Carrot", 4320000, 0, farmX, farmY));
//				System.out.println("farmland is planted:" + this.farmland[0].full);
//			}
//			
//		}
//		if (this.farmland[0].full == true) {
//			Texture c = new Texture("carrot_stage1.png");
//			game.batch.draw(c, farmX,farmY);
//		}
        //this.farmland[0].planted.grow();  // try to grow plant

//        if (Gdx.input.isKeyPressed(Input.Keys.W) && playery < 360) {
//            System.out.println("W");
//
//            playery += Gdx.graphics.getDeltaTime() * Speed;
//        }
//        if (Gdx.input.isKeyPressed(Input.Keys.S) && playery > 0) {
//            System.out.println("S");
//            playery -= Gdx.graphics.getDeltaTime() * Speed;
//        }
//        if (Gdx.input.isKeyPressed(Input.Keys.A) && playerx > 0) {
//            System.out.println("A");
//            playerx -= Gdx.graphics.getDeltaTime() * Speed;
//        }
//        if (Gdx.input.isKeyPressed(Input.Keys.D) && playerx < 1200) {
//
//            System.out.println("D");
//            playerx += Gdx.graphics.getDeltaTime() * Speed;
//        }


        //
        // Barn
        //

        coins.begin();
        coins.draw(coin, 32, 605);
        coins.end();


        game.batch.end();
        batch.end();
    }


    @Override
    public void resize(int width, int height) {
        // TODO Auto-generated method stub

    }

    @Override
    public void pause() {
        // TODO Auto-generated method stub

    }

    @Override
    public void resume() {
        // TODO Auto-generated method stub

    }

    @Override
    public void hide() {
        // TODO Auto-generated method stub

    }

    @Override
    public void dispose() {
        // TODO Auto-generated method stub
        for (int i = 0; i < 10; i++) {
            crops.removeImg(i);
            crops.removeCropIMG(i);
        }
        inventoryImg.dispose();

    }

}
