package com.mygdx.game;

import java.util.ArrayList;
import java.util.Arrays;

import com.badlogic.gdx.graphics.Texture;

public class Inventory {
	String selectItem;
	ArrayList<InventoryItem> seeds;
    Crop[][] items;  // 8x8 item grid

    //
    // Constructor for Inventory
    //
    public Inventory() {
    	seeds = new ArrayList<>(7);
    	selectItem = "";
        items = new Crop[2][7];
        int y = 643;//crop y position
        int id = 1;//auto generate IDs
        for (int i = 0; i < items.length; i++) {
            int x = 814;//crop x position
            for (int j = 0; j < items[i].length; j++) {
                Crop c = new Crop(id++, x, y);
                if (i == 0) {
                    c.setQuantity(0);
                } else {
                    c.setQuantity(1);
                }
                items[i][j] = c;
                x += 74;
            }
            y += 50;
        }
        ArrayList<String> names = new ArrayList<String>(Arrays.asList("carrot seed", "corn seed", "potato seed", 
        		"wheat seed", "tomato seed", "sunflower seed", "watermelon seed"));
        y = 50;
        int x = 780;
        for(int i = 0; i < 7; i++) {
        	InventoryItem seed = new InventoryItem(names.get(i), x, y, i);
        	seeds.add(seed);
        	x += 72;
        }
    }
    
    public int getItemX(int i) {
    	return seeds.get(i).posX;
    }
    public int getItemY(int i) {
    	return seeds.get(i).posY;
    }
    public String getItemName(int i) {
    	return seeds.get(i).name;
    }
    public void setSelect(int i) {
    	selectItem = seeds.get(i).name;
    }
    public String getSelect() {
    	String result = selectItem;
    	selectItem = "";
    	return result;
    }
    public boolean checkExist() {
    	for(int i = 0; i < 7; i++) {
    		if (items[0][i].quantity > 0 && selectItem == seeds.get(i).name) {
    			items[0][i].quantity--;
    			return true;
    		}
    	}
    	return false;
    }
    public boolean matchSelect(int i) {
    	return selectItem == seeds.get(i).name;
    }
    //
    // adds Crop c to inventory, returns 0 on success, returns -1 on failure (inventory full)
    //
    public int addSeed(Crop c) {
        for (int j = 0; j < items[0].length; j++) {
            if (items[0][j].equals(c)) {
                items[0][j].setQuantity(items[0][j].quantity + 1);
                return 0;
            }
        }
        return -1;  // inventory must be full
    }

    //
    // adds Crop c to inventory, returns 0 on success, returns -1 on failure (inventory full)
    //
    public int addCrop(Crop c) {
        for (int j = 0; j < items[1].length; j++) {
            if (items[1][j].equals(c)) {
                items[1][j].setQuantity(items[1][j].quantity + 1);
                return 0;
            }
        }
        return -1;  // inventory must be full
    }

    public int collectedSeeds(){
        int collected=0;
        for (int j = 0; j < items[0].length; j++) {
            if (items[0][j].quantity>0) {
                collected++;
            }
        }
        return collected;
    }
    
    public void collectCrop(int i, int j, int amount) {
    	items[i][j].quantity += amount;
    }

    //
    // given crop c, removes it from inventory, returns 0 on success, -1 on failure
    //
    public int removeItem(Crop c) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (items[i][j].equals(c)) {  // found it!
                    items[i][j] = null;
                    return 0;
                }
            }
        }
        return -1;  // not found
    }

    // given indices i and j, returns crop/seed
    public Crop getItemAt(int i, int j) {
        return items[i][j];
    }

    //
    // sells Crop c in inventory, returns quantity on success, returns -1 on failure (inventory empty)
    //
    public int sellCrop(Crop c, boolean all) {
        for (int j = 0; j < items[1].length; j++) {
            int q=items[1][j].quantity;
            if (items[1][j].equals(c) &&  q> 0) {
                items[1][j].setQuantity(all ? 0 : q - 1);
                return q;
            }
        }
        return -1;  // inventory must be full
    }

    //
    // returns names of items in inventory so we can display it later
    //
    public String[][] displayNames() {
        String[][] names = new String[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (items[i][j] == null) {  // if null give it None as name
                    names[i][j] = "None";
                } else {
//                    names[i][j] = items[i][j].getName();  // name = crop name
                }
            }
        }
        return names;
    }
}