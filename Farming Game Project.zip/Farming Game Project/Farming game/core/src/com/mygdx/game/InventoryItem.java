package com.mygdx.game;

public class InventoryItem {
    String name;
    int posX;
    int posY;
    int id;

    public InventoryItem(String n, int x, int y, int id) {
        name = n;
        posX = x;
        posY = y;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int posX() {
        return posX;
    }

    public int posY() {
        return posY;
    }
}
