package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class MainMenuScreen implements Screen{
	// variables
	FarmingSim game;
	Texture playButtonNormal;
	Texture playButtonHovered;
	Texture backgroundTexture;
	TextureRegion mainBackground;
	
	int PLAY_WIDTH = 200;
	int PLAY_HEIGHT = 100;

	//
	// constructor for main menu
	//
	public MainMenuScreen (FarmingSim game) {
		this.game = game;
		this.playButtonNormal = new Texture("playButton_inactive.PNG");
		this.playButtonHovered = new Texture("playButton_active.PNG");
		this.backgroundTexture = new Texture("mainmenubackground.PNG");
		this.mainBackground = new TextureRegion(backgroundTexture, 0,0, FarmingSim.WIDTH, FarmingSim.HEIGHT);
	}
	
	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		Gdx.gl.glClearColor(0.15f, 0.15f, 0.3f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		game.batch.begin();
		game.batch.draw(mainBackground, 0, 0);
//		System.out.println(Gdx.input.getX());
//		System.out.println(Gdx.input.getY());
		if (Gdx.input.getX() > FarmingSim.WIDTH/2 - 100 && Gdx.input.getX() < FarmingSim.WIDTH/2 - 100 + PLAY_WIDTH    &&    Gdx.input.getY() < FarmingSim.HEIGHT* 0.75  && Gdx.input.getY() > FarmingSim.HEIGHT* 0.75 - PLAY_HEIGHT) {
			game.batch.draw(playButtonHovered, FarmingSim.WIDTH/2 - 100,FarmingSim.HEIGHT/4, PLAY_WIDTH, PLAY_HEIGHT);
			if(Gdx.input.isTouched()) {
				this.dispose();
				game.setScreen(new GameScreen(game));
			}
		}
		else {
			game.batch.draw(playButtonNormal, FarmingSim.WIDTH/2 - 100,FarmingSim.HEIGHT/4, PLAY_WIDTH, PLAY_HEIGHT);	
		}
		
		
		game.batch.end();
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}


}
