package com.mygdx.game;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class Shop {
    Texture shopButton;
    Texture shopMenu;
    int shopButtonX;
    int shopButtonY;
    int shopMenuX;
    int shopMenuY;
    List<Crop> items;//List to maintain items that can be bought
    List<Crop> sellItems;//List to maintain items that can be sold
    Hashtable<String, Integer> buy;
    Hashtable<String, Integer> sell;
    boolean isClicked;
    boolean isSelling;

    public Shop() {
        populate();
    }

    public Shop(int x, int y) {
        shopButtonX = x;
        shopButtonY = y;
        shopMenuX = 100;
        shopMenuY = 100;
        shopButton = new Texture("shop/shopButton.png");
        shopMenu = new Texture("shop/shopBuy.png");
        populate();
    }

    private void populate() {
        isClicked = false;
        isSelling = false;
        items = new ArrayList<>();
        sellItems = new ArrayList<>();

        //add some items/crops
        items.add(new Crop(1, 192, 435, 10));
        items.add(new Crop(2, 328, 435, 5));
        items.add(new Crop(3, 471, 435, 10));
        items.add(new Crop(4, 604, 435, 15));
        items.add(new Crop(5, 748, 435, 15));
        items.add(new Crop(6, 877, 435, 10));
        items.add(new Crop(7, 1012, 435, 5));

        //add some items/crops to sell
        sellItems.add(new Crop(8, 192, 435, 15));
        sellItems.add(new Crop(9, 328, 435, 10));
        sellItems.add(new Crop(10, 471, 435, 15));
        sellItems.add(new Crop(11, 604, 435, 20));
        sellItems.add(new Crop(12, 748, 435, 20));
        sellItems.add(new Crop(13, 877, 435, 15));
        sellItems.add(new Crop(14, 1012, 435, 10));
    }

    public int getButtonX() {
        return shopButtonX;
    }

    public int getButtonY() {
        return shopButtonY;
    }

    public int getMenuX() {
        return shopMenuX;
    }

    public int getMenuY() {
        return shopMenuY;
    }

    public boolean getClicked() {
        return isClicked;
    }

    public boolean isSelling() {
        return isSelling;
    }

    public void setSelling(boolean selling) {
        isSelling = selling;
    }

    public void setClicked(boolean click) {
        isClicked = click;
    }

    public int getBuyPrice(String name) {
        return buy.get(name);
    }

    public int getSellPrice(String name) {
        return buy.get(name);
    }

    public Texture getButtonImg() {
        return shopButton;
    }

    public void setButtonImg(String img) {
        shopButton = new Texture(img);
    }

    public Texture getMenuImg() {
        return shopMenu;
    }

    public void setMenuImg(String img) {
        shopMenu = new Texture(img);
    }

    public void removeImg() {
        shopMenu.dispose();
    }

    public List<Crop> getSellItems() {
        return sellItems;
    }

    public List<Crop> getItems() {
        return items;
    }
}