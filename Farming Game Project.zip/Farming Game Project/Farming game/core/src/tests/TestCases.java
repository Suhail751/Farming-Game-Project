package tests;

import static org.junit.Assert.*;

import com.mygdx.game.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Timer;

public class TestCases {

    Shop shop;
    Barn barn;
    Inventory inventory;
//    CropField crops;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {

    }

    @Before
    public void setUp() throws Exception {
        shop = new Shop();
        barn = new Barn();
        inventory = new Inventory();
//        crops = new CropField();
    }

    @Test
    public void testCropUnlockSet() {
        Crop test = new Crop(1, 50, 50, 34);
        test.setUnlocked(true);
        assertTrue(test.isUnlocked());
    }
    @Test
    public void testCropGetQuantity() {
        Crop test = new Crop(1, 50, 50, 34);
        test.setQuantity(10);
        assertEquals(10, test.getQuantity());
    }
    
    @Test
    public void testCropGetPrice() {
        Crop test = new Crop(1, 50, 50, 34);
        assertEquals(34, test.getPrice(), 0.1);
    }
    @Test
    public void testCropTime() {
        Crop test = new Crop(1, 50, 50, 34);
        Timer T = new Timer();
        test.runCropTime(T);
        try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        assertEquals(true, test.isReadyToHarvest());
    }
    
    @Test
    public void testCropIsPlanted() {
        Crop test = new Crop(1, 50, 50, 34);
        test.setPlant(true);
        assertEquals(true, test.getPlanted());
    }
    
    @Test
    public void testCropIsFull() {
        Crop test = new Crop(1, 50, 50, 34);
        test.setFull(true);
        assertEquals(true, test.getFull());
    }
    
    @Test
    public void testCropIsSelected() {
        Crop test = new Crop(1, 50, 50, 34);
        test.setIsSelect(true);
        assertEquals(true, test.getIsSelect());
    }

    @Test
    public void testCropGetX() {
        Crop test = new Crop(1, 50, 50, 34);
        assertEquals(50, test.getX());
    }
    
    @Test
    public void testCropGetY() {
        Crop test = new Crop(1, 50, 50, 34);
        assertEquals(50, test.getY());
    }
    
    @Test
    public void testCropGetCropID() {
        Crop test = new Crop(1, 50, 50, 34);
        assertEquals(1, test.getCropID());
    }
    
    @Test
    public void testInventoryItemGetName() {
        InventoryItem test = new InventoryItem("testName", 50, 50, 1);
        assertEquals("testName", test.getName());
    }

    @Test
    public void testBarnUpgrade() {
        assertEquals(0, barn.getLevel());
        int n = barn.upgrade(50);
        assertEquals(-100, n);

        n = barn.upgrade(100);
        assertTrue(n > 0);
        assertEquals(1, barn.getLevel());
    }

    @Test
    public void testShopOpen() {
        assertFalse(shop.getClicked());

        shop.setClicked(true);
        assertTrue(shop.getClicked());
    }

    @Test
    public void testShopNotEmpty() {
        assertFalse(shop.isSelling());
        assertNotNull(shop.getItems());
    }

    @Test
    public void testBuy() {
        int BUY_SUCCESS = 0;
        //Buy fail, no such Crop in shop
        Crop crop = new Crop(111, 0, 1);
        assertNotEquals(BUY_SUCCESS, inventory.addSeed(crop));

        //Buy success
        crop = shop.getItems().get(0);
        assertEquals(BUY_SUCCESS, inventory.addSeed(crop));
    }

    @Test
    public void testBoughtSeeds() {
        Crop crop = shop.getItems().get(0);
        inventory.addSeed(crop);
        assertEquals(1, inventory.collectedSeeds());
    }

    @Test
    public void testSellCrop() {
        Crop crop = shop.getSellItems().get(shop.getSellItems().size() - 1);
        int sold = inventory.sellCrop(crop, false);
        assertEquals(1, sold);
    }

    @Test
    public void testSellNoCrop() {
        Crop crop = shop.getSellItems().get(shop.getSellItems().size() - 1);
        inventory.sellCrop(crop, false);
        int sold = inventory.sellCrop(crop, false);
        assertEquals(-1, sold);
    }

    @Test
    public void testInventorySelection() {
        //Select first seed
        inventory.setSelect(0);
        //second is not selected but first
        assertFalse(inventory.matchSelect(1));

        //selected is "carrot seed"
        assertEquals("carrot seed", inventory.getSelect());

        //selection reset
        assertEquals("", inventory.getSelect());
    }

    @Test
    public void testHarvest() {
        Crop crop = inventory.getItemAt(0, 0);
        crop.runCropTime(new Timer());
        assertFalse(crop.isReadyToHarvest());
        try {
            Thread.sleep(5500);
            assertTrue(crop.isReadyToHarvest());
        } catch (InterruptedException e) {
        }
    }

}
