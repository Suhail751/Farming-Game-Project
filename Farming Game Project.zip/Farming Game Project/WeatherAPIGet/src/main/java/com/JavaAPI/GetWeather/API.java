package com.JavaAPI.GetWeather;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.*;
import com.google.gson.reflect.*;

public class API {

	public static Map<String, Object> jsonToMap(String str) {
		Map<String, Object> map = new Gson().fromJson(
				str, new TypeToken<HashMap<String, Object>>() {}.getType());
	return map;
	}
	public class Founder{
		String name;
		int count;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String API_KEY = "b5989b51efee5cb447037365a92a5d16";
		String Location = "Chicago";
		String urlString = "https://api.openweathermap.org/data/2.5/weather?q=" + Location 
				+ "&appid=" + API_KEY + "&units=imperial";
		try {
			StringBuilder result = new StringBuilder();
			URL url = new URL(urlString);
			URLConnection conn = url.openConnection();
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while((line = rd.readLine()) != null) {
				result.append(line);
			}
			rd.close();
			System.out.println(result);
//			result.getJsonArray()
//			Type foundList = new TypeToken<ArrayList<Founder>>() {}.getType();
//			List<Founder> founders = new Gson().fromJson(result.get("weather").toString(), null);
			Map<String, Object> respMap = jsonToMap(result.toString());
			@SuppressWarnings("unchecked")
			ArrayList<Map<String, Object>> weathers = (ArrayList<Map<String, Object>>) respMap.get("weather");
			
			Map<String, Object> weatherMap = weathers.get(0);
			System.out.println("Weather Type: " + weatherMap.get("main"));
//			Map<String, Object> weatherMap = jsonToMap(respMap.get("weather").toString());
//			ArrayList<String> weatherArray = new Gson().fromJson(weatherMap.toString(), new TypeToken<ArrayList<String>>() {}.getType());
//			System.out.println(weatherArray);
//			Map<String, Object> weather = jsonToMap(weatherMap.get("main").toString());
//			System.out.println(weather);
			Map<String, Object> mainMap = jsonToMap(respMap.get("main").toString());
			Map<String, Object> windMap = jsonToMap(respMap.get("wind").toString());
			
//			System.out.println("Weather: " + weatherMap.get("main"));
			System.out.println("Current Temp: " + mainMap.get("temp"));
			System.out.println("Current Hum: " + mainMap.get("humidity"));
			System.out.println("Wind Speeds: " + windMap.get("speed"));
			System.out.println("Wind Angle: " + windMap.get("deg"));
			
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}

}
