package entity;

import java.awt.image.BufferedImage;
import java.io.IOException;

import main.controls;
import main.gameView;


public class player extends entity {
	
	gameView screen; //view
	controls keys; // for controlling the player
	
	
	
	public player(gameView screen , controls keys) {
		
		this.screen = screen;
		this.keys = keys;
		setValue();
		instertImgPlayer();
	
		
	}
	
	public void setValue () {
		
		
		x = 100;
		y = 100; 
		speed = 4;
		movment = "up";
		
	}
	
	public void instertImgPlayer() {
		try {
			up1 = //insert image
			up2 = //insert image
			down1 = //insert image
			down2 = //insert image
			right1 = //insert image
			right2 = //insert image
			left1 = //insert image
			left2 = //insert image	
		
		}catch(IOException e) {
			e.printStackTrace();
		}
			
		}
	
	
	public void update () { //player movements updates
		
		if (keys.upP == true || keys.downP == true || keys.leftP == true || keys.rightP == true) {
			
			if(keys.upP == true) {
				movment = "up";
				y -= speed;
			}
			else if(keys.downP == true) {
				movment = "down";
				x += speed;
			}
			else if(keys.leftP == true) {
				movment = "left";
				x -= speed;
		}
			else if(keys.rightP == true) {
				movment = "right";
				x += speed;

	}
			farmerCounter++; //updates 
			if(farmerCounter > 12 ) {
				if(farmerNum == 1) {
					farmerNum =2; 
				}
				else if(farmerNum == 2) {
					farmerNum =1;
				}
				farmerCounter =0;
			}
		}
				
		if(keys.upP == true) {
			movment = "up";
			y -= speed;
		}
		else if(keys.downP == true) {
			movment = "down";
			x += speed;
		}
		else if(keys.leftP == true) {
			movment = "left";
			x -= speed;
	}
		else if(keys.rightP == true) {
			movment = "right";
			x += speed;

}
		farmerCounter++; //updates 
		if(farmerCounter > 12 ) {
			if(farmerNum == 1) {
				farmerNum =2; 
			}
			else if(farmerNum == 2) {
				farmerNum =1;
			}
			farmerCounter =0;
		}
		
	}
	
	public void draw() { //changes the images depends on the key pressed with walking animation using 2 images for each key 
		
		BufferedImage image = null;
		
		switch(movment) {
		case "up":
			if (farmerNum == 1) {
				image = up1;
			}
			if (farmerNum == 2) {
				image = up2;
			}
			break;
		case "down":
			if (farmerNum == 1) {
				image = down1;
			}
			if (farmerNum == 2) {
				image = down2;
			}
			break;
		case "right":
			if (farmerNum == 1) {
				image = right1;
			}
			if (farmerNum == 2) {
				image = right2;
			}
			break;
		case "left":
			if (farmerNum == 1) {
				image = left1;
			}
			if (farmerNum == 2) {
				image = left2;
			}
			break;
		}
	}
	
	
	
	
	
	
	
}
